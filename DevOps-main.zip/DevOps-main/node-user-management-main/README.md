# node-express

This is a simple ExpressJs Application that adds users to the database
and lists in the secreen.


# Requirements
This application needs a mysql instance with a database name "test"

# How to run
To run this Application locally:
```
npm install
npm start
```